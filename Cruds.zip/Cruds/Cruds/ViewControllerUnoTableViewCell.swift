//
//  ViewControllerUnoTableViewCell.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit

class ViewControllerUnoTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblNameMedicamento: UILabel!
    
    @IBOutlet weak var lblCodigoMedicamento: UILabel!
    
    @IBOutlet weak var lblColorMedicamento: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
