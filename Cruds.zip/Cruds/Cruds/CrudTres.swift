//
//  CrudTres.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit
import Firebase

class CrudTres: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var refPrograma: DatabaseReference!

    @IBOutlet weak var txtFieldNmePrograma: UITextField!
    @IBOutlet weak var txtFieldTipoPrograma: UITextField!
    @IBOutlet weak var txtFieldEncargado: UITextField!
    @IBOutlet weak var lblMensaje: UILabel!
    
    @IBOutlet weak var tblProgramas: UITableView!
    
    var programaList = [ProgramaModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let progra = programaList [indexPath.row]
        let alertController = UIAlertController(title:progra.name, message: "Dame Datos Nuevos", preferredStyle:.alert)
        
        let editarAction = UIAlertAction(title: "Editar", style:.default){(_) in
            let id = progra.id
            let name = alertController.textFields?[0].text
            let tipo = alertController.textFields?[1].text
            let encargado = alertController.textFields?[2].text
            
            self.editarPrograma(id: id!, name: name!, tipo: tipo!, encargado: encargado!)
        
            
        }
        let eliminarAction = UIAlertAction(title: "Borrar", style:.default){(_) in
            self.eliminarPrograma(id: progra.id!)
            
            
            
        }
        alertController.addTextField{(textField) in
            textField.text = progra.name
        }
        alertController.addTextField{(textField) in
            textField.text = progra.tipo
        }
        alertController.addTextField{(textField) in
            textField.text = progra.encargado
        }
        
        alertController.addAction(editarAction)
        alertController.addAction(eliminarAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    
    func editarPrograma(id: String, name: String, tipo: String, encargado: String){
        
        let progra = [
            "id": id,
            "programaName": name,
            "programaTipo": tipo,
            "programaEncargado": encargado
        
                    ]
        refPrograma.child(id).setValue(progra)
        lblMensaje.text = "Programa Editado"
        
        
    }
    func eliminarPrograma(id: String){
        refPrograma.child(id).setValue(nil)
        if programaList.count == 1{
            programaList.removeAll()
            tblProgramas.reloadData()
        }
        
    }
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return programaList.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTresTableViewCell
        let medica: ProgramaModel
        
        medica = programaList[indexPath.row]
        
        cell.lblNamePrograma.text = medica.name
        cell.lblTipoPrograma.text = medica.tipo
        cell.lblEncargado.text = medica.encargado
        
        return cell
    }
    
    
    
    
    @IBAction func btnAddPrograma(_ sender: UIButton) {
        addPrograma()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //FirebaseApp.configure()
        if FirebaseApp.app() == nil{
            FirebaseApp.configure()
        }
        
        refPrograma = Database.database().reference().child("programa")
        
        refPrograma.observe(DataEventType.value, with:{(snapshot) in
            if snapshot.childrenCount>0{
                self.programaList.removeAll()
                
                for programa in snapshot.children.allObjects as![DataSnapshot]{
                    let programaObject = programa.value as? [String: AnyObject]
                    let programaName = programaObject? ["programaName"]
                    let programaTipo = programaObject? ["programaTipo"]
                    let programaEncargado = programaObject? ["programaEncargado"]
                    let programaId = programaObject? ["id"]
                    
                    let progra = ProgramaModel(id: programaId as! String?, name: programaName as! String?, tipo: programaTipo as! String?, encargado: programaEncargado as! String?)
                    
                    self.programaList.append(progra)
                }
                self.tblProgramas.reloadData()
            }
            
        })
        
    }
    func addPrograma(){
        let key = refPrograma.childByAutoId().key
        //NombreDe como Aparrece EN LA BASE DE DATOS CAMBIA
        let programa = ["id":key,
                        "programaName": txtFieldNmePrograma.text! as String?,
                        "programaTipo": txtFieldTipoPrograma.text! as String?,
                        "programaEncargado": txtFieldEncargado.text! as String?
        
                        ]
        
        refPrograma.child(key!).setValue(programa)
        lblMensaje.text = "Programa Guardado"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
