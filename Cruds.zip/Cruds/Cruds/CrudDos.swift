//
//  CrudDos.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit
import Firebase

class CrudDos: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var refAnimal: DatabaseReference!
    
    @IBOutlet weak var txtFieldNombreAnimal: UITextField!
    @IBOutlet weak var txtTipoAnimal: UITextField!
    @IBOutlet weak var txtPesoAnimal: UITextField!
    @IBOutlet weak var txtFieldColorAnimal: UITextField!
    @IBOutlet weak var lblMensaje: UILabel!
    
    
    @IBOutlet weak var tblAnimales: UITableView!
    
    var animalList = [AnimalModel]()
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let animal = animalList[indexPath.row]
        let alertController = UIAlertController(title: animal.name, message: "Dame datos nuevos", preferredStyle:.alert)
        
        let editarAction = UIAlertAction(title: "Editar", style:.default){(_) in
            
            let id = animal.id
            
            let name = alertController.textFields?[0].text
            let tipo = alertController.textFields?[1].text
            let peso = alertController.textFields?[2].text
            let color = alertController.textFields?[3].text
            
            self.editarAnimal(id: id!, name: name!, tipo: tipo!, peso: peso!, color: color!)
            
        }
        let borrarAction = UIAlertAction(title: "Borrar", style:.default){(_) in
            self.eliminarAnimal(id: animal.id!)
            
        }
        
        alertController.addTextField{(textField) in
            textField.text = animal.name
        }
        alertController.addTextField{(textField) in
            textField.text = animal.tipo
        }
        alertController.addTextField{(textField) in
            textField.text = animal.peso
        }
        alertController.addTextField{(textField) in
            textField.text = animal.color
        }
        
        alertController.addAction(editarAction)
        alertController.addAction(borrarAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    
    func editarAnimal(id:String, name: String, tipo: String, peso: String, color: String){
        
        let anim = [
            "id": id,
            "animalName": name,
            "animalTipo": tipo,
            "animalPeso": peso,
            "animalColor": color
        
                    ]
        refAnimal.child(id).setValue(anim)
        lblMensaje.text = "Dato editado"
        
    }
    
    func eliminarAnimal(id: String){
        refAnimal.child(id).setValue(nil)
        if animalList.count == 1{
            animalList.removeAll()
            tblAnimales.reloadData()
            //tblMedicamentos.reloadData()
        }
    
    }
    
    
    
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animalList.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerDosTableViewCell
        
        let animal: AnimalModel
        animal = animalList[indexPath.row]
        
        cell.lblNameAnimal.text = animal.name
        cell.lblTipoAnimal.text = animal.tipo
        cell.lblPesoAnimal.text = animal.peso
        cell.lblColorAnimal.text = animal.color
        
        return cell
    }
    
  
    
    @IBAction func btnAddAnimal(_ sender: UIButton) {
        addAnimal()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       // FirebaseApp.configure()
        if FirebaseApp.app() == nil{
            FirebaseApp.configure()
        }
        
        refAnimal = Database.database().reference().child("animal");
        refAnimal.observe(DataEventType.value, with:{(snapshot) in
            
            if snapshot.childrenCount>0{
                self.animalList.removeAll()
                
                for animal in snapshot.children.allObjects as![DataSnapshot]{
                    let animalObject = animal.value as? [String: AnyObject]
                    let animalName = animalObject?["animalName"]
                    let animalTipo = animalObject?["animalTipo"]
                    let animalPeso = animalObject?["animalPeso"]
                    let animalColor = animalObject?["animalColor"]
                    let animalId = animalObject?["id"]
                    
                    
                    let anima = AnimalModel(id: animalId as! String?, name: animalName as! String?, tipo: animalTipo as! String?, peso: animalPeso as! String?, color: animalColor as! String?)
                    
                    self.animalList.append(anima)
                }
                self.tblAnimales.reloadData()
            }
            
            
        })
    }
    
    
    func addAnimal(){
        let key  = refAnimal.childByAutoId().key
        
        let animal  = ["id":key,
                            "animalName": txtFieldNombreAnimal.text! as String,
                            "animalTipo": txtTipoAnimal.text! as String,
                            "animalPeso": txtPesoAnimal.text! as String,
                            "animalColor": txtFieldColorAnimal.text! as String,
            
        ]
        
        refAnimal.child(key!).setValue(animal)
        lblMensaje.text  = "Animal Guardado"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
