//
//  ProgramaModel.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/7/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

class ProgramaModel{
        var id: String?
        var name: String?
        var tipo: String?
        var encargado: String?
        
        init(id: String?, name: String?, tipo: String?, encargado: String?){
            
            self.id = id;
            self.name = name;
            self.tipo = tipo;
            self.encargado = encargado;
            
        }
    
}
