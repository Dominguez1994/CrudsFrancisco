//
//  ViewControllerDosTableViewCell.swift
//  Cruds
//
//  Created by Francisco Dominguez on 5/6/19.
//  Copyright © 2019 Francisco Dominguez. All rights reserved.
//

import UIKit

class ViewControllerDosTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblNameAnimal: UILabel!
    @IBOutlet weak var lblTipoAnimal: UILabel!
    @IBOutlet weak var lblPesoAnimal: UILabel!
    @IBOutlet weak var lblColorAnimal: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
